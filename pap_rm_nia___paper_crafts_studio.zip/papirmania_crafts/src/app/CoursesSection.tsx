'use client';
import Button from'../components/ui/Button';

interface Course {
  id: string;
  title: string;
  price: string;
  description: string;
  features: string[];
}

interface CoursesSectionProps {
  courses: Course[];
  loading: boolean;
}

export default function CoursesSection({ courses, loading }: CoursesSectionProps) {
  const handleLearnMoreClick = () => {
    // Handle learn more action
  }

  const handleJoinWorkshopClick = (courseId: string) => {
    // Handle join workshop action
  }

  return (
    <section className="w-full bg-[#3b3935]" id="courses-section">
      <div className="w-full">
        <div className="flex flex-col justify-start items-center w-full">
          <div className="w-full max-w-content mx-auto px-[40px] sm:px-[60px] lg:px-[80px] py-[56px] sm:py-[84px] lg:py-[112px]">
            <div className="flex flex-col justify-start items-center w-full max-w-[768px] mx-auto px-4 sm:px-8 lg:px-0">
              <span
                className="text-base font-extrabold leading-[150%] text-center uppercase mb-2"
                style={{ fontFamily: 'DM Sans', color: 'var(--light, #ECE6E1)' }}
              >
                Kurzusok
              </span>

              <h2
                className="text-[30px] sm:text-[45px] lg:text-[60px] font-normal leading-[110%] text-center text-white mb-4 lg:mb-6"
                style={{ 
                  fontFamily: 'Maname',
                  textShadow: '0 0 4px rgba(224, 168, 136, 0.40)'
                }}
              >
                Kézműves kurzusok
              </h2>

              <p
                className="text-[18px] sm:text-[19px] lg:text-[20px] font-normal leading-[160%] text-center text-[#E6E4DC]"
                style={{ fontFamily: 'DM Sans' }}
              >
                Ha szeretnél új kézműves technikákat tanulni, látogass el a workshopomra!
              </p>
            </div>

            {/* Courses Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 w-full">
              
              {/* Left Column - Learn More Card */}
              <div className="bg-[#27414c] rounded-[16px] p-[24px] sm:p-[36px] lg:p-[48px] h-auto">
                <div className="flex flex-col gap-[12px] sm:gap-[14px] lg:gap-[16px] justify-start items-start w-full">
                  
                  <span 
                    className="text-base font-extrabold leading-[150%] text-center uppercase text-white"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Újrahasznosítás
                  </span>
                  
                  <div className="flex flex-col gap-[16px] sm:gap-[24px] lg:gap-[32px] justify-start items-center w-full">
                    
                    <h3 
                      className="text-[24px] sm:text-[36px] lg:text-[48px] font-normal leading-[110%] text-left text-white"
                      style={{ 
                        fontFamily: 'Maname',
                        textShadow: '0 0 4px rgba(73, 53, 24, 0.40)'
                      }}
                    >
                      Miről tanulhatsz?
                    </h3>
                    
                    <p 
                      className="text-[16px] sm:text-[17px] lg:text-[18px] font-normal leading-[160%] text-left text-white w-full mb-[22px] sm:mb-[33px] lg:mb-[44px]"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      Döntsd el, hogy mit szeretnél megtanulni. Cartonnage, könyvkötés, dobozkészítés vagy valami más?
                    </p>
                  </div>
                </div>
                
                <Button
                  text="Tudj meg többet"
                  text_font_size="text-base lg:text-lg"
                  text_font_family="DM Sans"
                  text_font_weight="font-normal"
                  text_line_height="leading-md"
                  text_color="text-white"
                  fill_background_color="bg-[#ffffff33]"
                  border_border_radius="rounded-[6px]"
                  effect_box_shadow="0px_1px_2px_#0807050c"
                  padding="10px 24px"
                  onClick={handleLearnMoreClick}
                  className="w-full sm:w-auto hover:bg-[#ffffff4d] transition-all duration-200"
                />
              </div>

              {/* Right Column - Workshop Cards */}
              <div className="flex flex-col gap-6 lg:gap-8 w-full">
                
                {loading ? (
                  <div className="flex flex-col gap-6">
                    {[...Array(2)].map((_, index) => (
                      <div key={index} className="bg-[#3b3935] rounded-[16px] p-8 animate-pulse">
                        <div className="h-12 bg-gray-300 rounded mb-4"></div>
                        <div className="h-20 bg-gray-300 rounded mb-4"></div>
                        <div className="h-10 bg-gray-300 rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  courses.slice(0, 2).map((course, index) => (
                    <div key={course.id} className="bg-[#3b3935] rounded-[16px] p-[24px] sm:p-[28px] lg:p-[32px] h-auto">
                      
                      {/* Workshop Header */}
                      <div className="flex flex-col sm:flex-row justify-center sm:justify-between items-start sm:items-center w-full gap-3 sm:gap-4 mb-[20px] sm:mb-[30px] lg:mb-[40px]">
                        <h4 
                          className="text-[20px] sm:text-[30px] lg:text-[40px] font-normal leading-[110%] text-left text-white"
                          style={{ 
                            fontFamily: 'Crimson Pro',
                            textShadow: '0 0 4px rgba(73, 53, 24, 0.40)'
                          }}
                        >
                          {course.title}
                        </h4>
                        
                        <Button
                          text={course.price}
                          text_font_size="text-sm lg:text-[18px]"
                          text_font_family="DM Sans"
                          text_font_weight="font-normal"
                          text_line_height="leading-md"
                          text_color="text-[#ece6e1]"
                          fill_background_color="bg-[#14141466]"
                          border_border_radius="rounded-[4px]"
                          padding="8px 16px"
                          className="w-full sm:w-auto"
                        />
                      </div>

                      {/* Workshop Content */}
                      <div className="flex flex-col gap-[6px] sm:gap-[7px] lg:gap-[8px] justify-start items-start w-full">
                        
                        {/* Description Section */}
                        <div className="py-[19px] sm:py-[29px] lg:py-[38px] w-full">
                          <div className="flex flex-row justify-start items-center w-full">
                            <p 
                              className="text-[16px] sm:text-[17px] lg:text-[18px] font-normal leading-[160%] text-left text-white w-[54%]"
                              style={{ fontFamily: 'DM Sans' }}
                            >
                              {course.description.split('\n').map((line, idx) => (
                                <span key={idx}>
                                  {line}
                                  {idx < course.description.split('\n').length - 1 && <br />}
                                </span>
                              ))}
                            </p>
                          </div>
                        </div>
                        
                        <Button
                          text="Jelentkezem"
                          text_font_size="text-sm lg:text-[18px]"
                          text_font_family="DM Sans"
                          text_font_weight="font-medium"
                          text_line_height="leading-md"
                          text_color="text-white"
                          fill_background_color="bg-[#ffffff19]"
                          border_border="border border-[#ffffff33]"
                          border_border_radius="rounded-[6px]"
                          effect_box_shadow="0px_1px_2px_#0807050c"
                          padding="10px 24px"
                          onClick={() => handleJoinWorkshopClick(course.id)}
                          className="w-full sm:w-auto hover:bg-[#ffffff33] transition-all duration-200"
                        />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}