'use client';
import { useState } from 'react';
import Image from'next/image';
import Button from'../ui/Button';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false)
  const [activeMenuItem, setActiveMenuItem] = useState('')
  const [isDarkMode, setIsDarkMode] = useState(false)

  const menuItems = [
    { id: 'kurzusok', label: 'Kurzusok', href: '/courses' },
    { id: 'technikak', label: 'Technikák', href: '/techniques' },
    { id: 'galeria', label: 'Galéria', href: '/gallery' },
    { id: 'rolam', label: 'Rólam', href: '/about' },
  ]

  const handleMenuItemClick = (itemId: string) => {
    setActiveMenuItem(itemId)
    setMenuOpen(false)
  }

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
  }

  return (
    <header className="w-full bg-background-overlay">
      <div className="w-full max-w-content mx-auto px-[32px] sm:px-[48px] lg:px-[64px]">
        <div className="flex flex-col lg:flex-row justify-between items-center py-[32px] gap-6">
          
          {/* Mobile Menu Toggle */}
          <button 
            className="block lg:hidden self-start p-2 hover:shadow-lg hover:scale-105 transition-all duration-300" 
            aria-label="Open menu"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <svg className="w-6 h-6 text-text-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>

          {/* Logo - Centered */}
          <div className="flex justify-center order-first lg:order-none">
            <Image
              src="/images/img_papermania_logo.svg"
              width={68}
              height={68}
              alt="Papírmánia Logo"
              className="w-[48px] h-[48px] sm:w-[56px] sm:h-[56px] lg:w-[68px] lg:h-[68px]"
            />
          </div>

          {/* Navigation Menu */}
          <nav className={`${menuOpen ? 'block' : 'hidden'} lg:block w-full lg:w-auto order-last lg:order-none`}>
            <div className="flex flex-col lg:flex-row gap-[16px] sm:gap-[24px] lg:gap-[32px] justify-center items-center">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  role="menuitem"
                  onClick={() => handleMenuItemClick(item.id)}
                  className={`font-extrabold text-base text-center uppercase leading-[150%] hover:shadow-lg hover:scale-105 transition-all duration-300 hover:text-white ${
                    activeMenuItem === item.id 
                      ? 'text-white scale-105' :''
                  }`}
                  style={{ fontFamily: 'DM Sans', color: 'var(--light, #ECE6E1)' }}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </nav>

          {/* Actions */}
          <div className="flex flex-row justify-end items-center gap-4 lg:gap-6">
            
            {/* Theme Toggle Switch */}
            <button
              onClick={toggleTheme}
              className="relative inline-flex items-center h-8 w-16 rounded-full bg-[#ffffff33] hover:bg-[#ffffff4d] transition-all duration-300"
              aria-label="Toggle theme"
            >
              <span
                className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform duration-300 ${
                  isDarkMode ? 'translate-x-9' : 'translate-x-1'
                }`}
              >
                {isDarkMode ? (
                  <Image
                    src="/images/img_lucide_moon.svg"
                    width={16}
                    height={16}
                    alt="Dark mode"
                    className="w-4 h-4 m-1"
                  />
                ) : (
                  <Image
                    src="/images/img_lucide_sun.svg"
                    width={16}
                    height={16}
                    alt="Light mode"
                    className="w-4 h-4 m-1"
                  />
                )}
              </span>
            </button>

            {/* Contact Button */}
            <Button
              text="Kapcsolat"
              text_font_size="text-lg"
              text_font_family="DM Sans"
              text_font_weight="font-medium"
              text_color="text-white"
              fill_background_color="bg-[#7B6A3F]"
              border_border="1.5px solid rgba(20, 20, 20, 0.40)"
              border_border_radius="rounded-[6px]"
              padding="10px 24px"
              className="hover:bg-[#5f5230] transition-all duration-200"
            />
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header